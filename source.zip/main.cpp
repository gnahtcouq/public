#include <conio.h>  // getch();

#include "menu.hpp"

int main() {
    // srand(time(NULL));
    menu();
    return 0;
}