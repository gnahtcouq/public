
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

int main() {
    /* Shaker sort (cải tiến của Bubble sort) gọi là sắp xếp rung lắc */

    system("pause");
    return 0;
}